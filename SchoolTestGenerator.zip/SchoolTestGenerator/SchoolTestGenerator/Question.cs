﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolTestGenerator
{
    internal class Question
    {
       
            public int ID { get; set; }
            public string Text { get; set; }
            public string[] Answers { get; set; }
            public int CorrectAnswer { get; set; }

            public Question(int id, string text, string[] answers, int correctAnswer)
            {
                ID = id;
                Text = text;
                Answers = answers;
                CorrectAnswer = correctAnswer;
            }
        
    }
}
