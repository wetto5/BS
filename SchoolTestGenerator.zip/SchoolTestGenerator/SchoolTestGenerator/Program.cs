﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolTestGenerator
{
    internal class Program
    {
        static void Main()
        {
            // Check if there are already files from previous execution
            if (Directory.GetFiles(Directory.GetCurrentDirectory(), "test*.txt").Length > 0)
            {
                Console.WriteLine("There are already files from a previous run.");
                Console.WriteLine("Please move them to an archive or delete them.");
                return;
            }

            // Load questions from the external file
            List<Question> questions = LoadQuestionsFromFile("questions.txt");
            if (questions.Count == 0)
            {
                Console.WriteLine("An error occurred while loading the questions.");
                return;
            }

            // Interactive menu for generating tests
            Console.WriteLine("Please enter the number of tests you want to generate:");
            int numTests = int.Parse(Console.ReadLine());

            for (int i = 1; i <= numTests; i++)
            {
                Console.WriteLine($"Please enter the number of questions for test {i}:");
                int numQuestions = int.Parse(Console.ReadLine());

                // Check if there are enough questions for this test
                if (numQuestions > questions.Count)
                {
                    Console.WriteLine("There are not enough questions to generate the test.");
                    return;
                }

                // Shuffle the questions
                ShuffleQuestions(questions);

                // Save the questions to an external file
                string fileName = $"test{i}.txt";
                SaveQuestionsToFile(fileName, questions.GetRange(0, numQuestions));
                Console.WriteLine($"A file '{fileName}' with {numQuestions} questions has been generated.");
            }

            Console.WriteLine("Test generation completed successfully.");
        }

        static List<Question> LoadQuestionsFromFile(string fileName)
        {
            List<Question> questions = new List<Question>();

            try
            {
                using (StreamReader reader = new StreamReader(fileName))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');

                        int id = int.Parse(parts[0]);
                        string question = parts[1];

                        string[] answers;
                        int correctAnswer;

                        if (parts.Length == 7)
                        {
                            // Case where there are six answer options and the correct answer
                            answers = new string[4];
                            Array.Copy(parts, 2, answers, 0, 4);
                            correctAnswer = int.Parse(parts[6]);
                        }
                        else if (parts.Length == 3)
                        {
                            // Case where there is only one answer (the correct answer)
                            answers = new string[1];
                            answers[0] = parts[2];
                            correctAnswer = 1;
                        }
                        else
                        {
                            Console.WriteLine($"Invalid question format: {line}");
                            continue;
                        }

                        Question q = new Question(id, question, answers, correctAnswer);
                        questions.Add(q);
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("An error occurred while reading the question file.");
            }

            return questions;
        }


        static void ShuffleQuestions(List<Question> questions)
        {
            Random rng = new Random();
            int n = questions.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                Question temp = questions[k];
                questions[k] = questions[n];
                questions[n] = temp;
            }
        }

        static void SaveQuestionsToFile(string fileName, List<Question> questions)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(fileName))
                {
                    foreach (Question question in questions)
                    {
                        writer.WriteLine($"{question.ID},{question.Text},{string.Join(",", question.Answers)}");
                    }
                }
            }
            catch (IOException)
            {
                Console.WriteLine("An error occurred while saving the test files.");
            }
        }
    }
}